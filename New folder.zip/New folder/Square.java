public class Square implements Polygon, Comparable<Square>
{
    private int sideLength;

    public Square(int sideLength) {
        this.sideLength = sideLength;
    }
    @Override
    public double getArea() {
        return sideLength * sideLength;
    }
    @Override
    public int getPerimeter(){
        return sideLength * 4;
    }

    // This will work after getArea() is implemented
    public String toString(){
        return "SQUARE:\t\t" + String.format("%.2f", getArea());
    }

    @Override
    public int compareTo(Square o) {
            if (getArea() == o.getArea()) {
                return 0;
            } else if (getArea() < o.getArea()) {
                return -1;
            } else if (getArea() > o.getArea()) {
                return 1;
            }
            return 0;
        }
    }
