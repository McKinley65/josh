//Joshua McKinley
//Partner: Dalton Hazelwood
//Submitted: 04/16/2021
public class BankFileFormatException extends Exception {
    public BankFileFormatException(String message) {
        super(message);
    }
}
