public class Rectangle  implements Polygon, Comparable<Rectangle> {
    private int length;
    private int width;

    public Rectangle(int length, int width) {
        this.length = length;
        this.width = width;
    }

    @Override
    public double getArea() {
        return length * width;
    }

    @Override
    public int getPerimeter() {
        return (2 * length) + (2 * width);
    }

    // This will work after getArea() is implemented
    public String toString() {
        return "RECTANGLE:\t" + String.format("%.2f", getArea());
    }

    @Override
    public int compareTo(Rectangle o) {
        {
            if (getArea() == o.getArea()) {
                return 0;
            } else if (getArea() < o.getArea()) {
                return -1;
            } else if (getArea() > o.getArea()) {
                return 1;
            }
            return 0;
        }
    }
}


