public interface Polygon {
        public double getArea();
        public int getPerimeter();
}
