public class Triangle implements Polygon, Comparable<Triangle> {
    private int side1;
    private int side2;
    private int side3;

    public Triangle(int side1, int side2, int side3) {
        this.side1 = side1;
        this.side2 = side2;
        this.side3 = side3;
    }
    @Override
    public double getArea(){
        int a = side1;
        int b = side2;
        int c = side3;

        if((a+b)>c && (a+c)>b && (b+c)>a);
        {
            int s = (a + b + c) / 2;
            double area = Math.sqrt(s * (s - a) * (s - b) * (s - c));

            return area;
        }
    }
    @Override
    public int getPerimeter(){
         return   side1 + side2 + side3;

        }


    // This will work after getArea() is implemented
    public String toString(){
        return "TRIANGLE:\t" + String.format("%.2f", getArea());
    }

    @Override
    public int compareTo(Triangle o) {
            if (getArea() == o.getArea()) {
                return 0;
            } else if (getArea() < o.getArea()) {
                return -1;
            } else if (getArea() > o.getArea()) {
                return 1;
            }
            return 0;
        }
    }

    // Hint for area: Heron's Formula
